<nav id="navbar">
    <div class="Logo">
            <h1><span class="Logo2">my_codingan</span></h1>
    </div>
    <div id="menu-icon" class="menu-icon">
      <i class="ph-fill ph-list"></i>
    </div>
    <ul id="menu-list" class="hidden">
      <li>
        <a href="{{ route('home') }}">Home</a>
      </li>
      <li>
        <a href="{{ route('about') }}">About</a>
      </li>
      <li>
        <a href="{{ route('project') }}">project</a>
      </li>
      <li>
        <a href="{{ route('serti') }}">certificate</a>
      </li>
    </ul>
  </nav>
