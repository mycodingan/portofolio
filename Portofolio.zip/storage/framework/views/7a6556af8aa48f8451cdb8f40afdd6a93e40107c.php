<?php $__env->startSection('title'); ?>
mycodingan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('conten'); ?>
<div class="aboutme">
    <div class="about">
        <img src="<?php echo e(asset('img/ppku/jojo.png')); ?>" alt="ppku" width="50%" class="imgage">
        <div class="fill">
            <h1 class="myco">About me</h1>
            <p class="bobo">Hi, my name is Joshua Wahyu, most people know me as mycodingan. I have expertise in programming, because I want to become a web developer who has expertise in coding.</p>
        </div>
    </div>
</div>
<?php echo $__env->make('portofolio.foooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kumpulan project laravel joshua\Portofolio\resources\views/portofolio/about/about.blade.php ENDPATH**/ ?>