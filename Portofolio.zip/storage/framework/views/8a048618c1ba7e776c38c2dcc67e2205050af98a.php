<?php $__env->startSection('title'); ?>
portofolio
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conten'); ?>
<div class="project">
    <h1>my project</h1>
    <div class="project-c">
        <div class="grid">
            <figure class="effect-marley"  data-aos="fade-right">
                <img src="<?php echo e(asset('img/API.png')); ?>" alt="img11" width="500"/>
                <figcaption>
                    <h2>project react <span>Api</span></h2>
                    <p>This is my React project when connecting Api From Vodio Web to my React code</p>
                    <a href="#">View more</a>
                </figcaption>
            </figure>
            <figure class="effect-marley" data-aos="fade-left">
                <img src="<?php echo e(asset('img/data.png')); ?>" alt="img11" width="500"/>
                <figcaption>
                    <h2>project react <span>    </span></h2>
                    <p>This is my React project to organize finances in the dormitory so that children can manage their finances</p>
                    <a href="#">View more</a>
                </figcaption>
            </figure>
            <figure class="effect-marley" data-aos="fade-right">
                <img src="<?php echo e(asset('img/clock.png')); ?>" alt="img11" width="500"/>
                <figcaption>
                    <h2>project clock <span>Digital</span></h2>
                    <p>This is my HTML project when I enter HTML, CSS and JS material. I made a digital clock.</p>
                    <a href="#">View more</a>
                </figcaption>
            </figure>
            <figure class="effect-marley"data-aos="fade-left">
                <img src="<?php echo e(asset('img/invrntory.png')); ?>" alt="img11" width="500"/>
                <figcaption>
                    <h2>project react <span>Api</span></h2>
                    <p>This is my Laravel inventory project when I was learning Laravel</p>
                    <a href="#">View more</a>
                </figcaption>
            </figure>
            <figure class="effect-marley"  data-aos="fade-right">
                <img src="<?php echo e(asset('img/crus.png')); ?>" alt="img11" width="500"/>
                <figcaption>
                    <h2>Laravel Crud Project</h2>
                    <p>I made Laravel crud when I first learned Laravel</p>
                    <a href="#">View more</a>
                </figcaption>
            </figure>
            <figure class="effect-marley"data-aos="fade-left">
                <img src="<?php echo e(asset('img/todo.png')); ?>" alt="img11" width="500"/>
                <figcaption>
                    <h2>project react <span>Todo</span></h2>
                    <p>This is my React project when I was asked to make a todo list</p>
                    <a href="#">View more</a>
                </figcaption>
            </figure>
        </div>
    </div>
</div>
<?php echo $__env->make('portofolio.foooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kumpulan project laravel joshua\Portofolio\resources\views/portofolio/project/project.blade.php ENDPATH**/ ?>