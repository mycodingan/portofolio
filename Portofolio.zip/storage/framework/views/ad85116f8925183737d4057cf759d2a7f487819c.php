<?php $__env->startSection('title'); ?>
    joshua
<?php $__env->stopSection(); ?>
<?php $__env->startSection('conten'); ?>
   <div class="certifica">
    <h1 class="jcerti">certificate</h1>
    <div class="image-container">
    <img src="<?php echo e(asset('certificate/Bootcam .jpg')); ?>" alt="" class="cece">
    <img src="<?php echo e(asset('certificate/Lomba ui ux.jpg')); ?>" alt="" class="cece">
    <img src="<?php echo e(asset('certificate/webinar laravel.jpeg')); ?>" alt="" class="cece">
</div>
   </div>
   <?php echo $__env->make('portofolio.foooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kumpulan project laravel joshua\Portofolio\resources\views/portofolio/certificate/certificate.blade.php ENDPATH**/ ?>