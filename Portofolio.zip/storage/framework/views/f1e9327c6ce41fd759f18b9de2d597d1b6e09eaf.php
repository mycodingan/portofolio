
<div class="quote">
    <div class="quodel">
        <h1>testimonial my friends</h1>
    </div>
    <section class="container">
      <div class="testimonial mySwiper">
        <div class="testi-content swiper-wrapper" >
          <div class="slide swiper-slide" data-aos="flip-left">
            <p>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam,
              saepe provident dolorem a quaerat quo error facere nihil deleniti
              eligendi ipsum adipisci, fugit, architecto amet asperiores
              doloremque deserunt eum nemo.
            </p>

            <i class="bx bxs-quote-alt-left quote-icon"></i>

            <div class="details">
              <span class="name">chealsea</span>
              <span class="job">Web Developer</span>
            </div>
          </div>
          <div class="slide swiper-slide" >
            <p>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam,
              saepe provident dolorem a quaerat quo error facere nihil deleniti
              eligendi ipsum adipisci, fugit, architecto amet asperiores
              doloremque deserunt eum nemo.
            </p>

            <i class="bx bxs-quote-alt-left quote-icon"></i>

            <div class="details">
              <span class="name">abeth</span>
              <span class="job">Web Developer</span>
            </div>
          </div>
          <div class="slide swiper-slide" data-aos="flip-left">
            <p>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam,
              saepe provident dolorem a quaerat quo error facere nihil deleniti
              eligendi ipsum adipisci, fugit, architecto amet asperiores
              doloremque deserunt eum nemo.
            </p>

            <i class="bx bxs-quote-alt-left quote-icon"></i>

            <div class="details">
              <span class="name">Marnie Lotter</span>
              <span class="job">Web Developer</span>
            </div>
          </div>
        </div>
      </div>
    </section>
</div>
<?php /**PATH D:\kumpulan project laravel joshua\Portofolio\resources\views/portofolio/tesmyfriend.blade.php ENDPATH**/ ?>