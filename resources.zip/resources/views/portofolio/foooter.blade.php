<div class="footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-logo">
                <img src="{{ asset('img/Logo.png') }}" alt="Company Logo" class="foto">
            </div>
            <div class="footer-links">
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">About Me</a></li>
                    <li><a href="#">Layanan</a></li>
                    <li><a href="#">certificate</a></li>
                </ul>
            </div>
            <div class="motivation">
                <div class="motiv">
                    <h2>motivation from me</h2>
                    <p> Dont give up easily just in small matters. Look for solutions and be a problem solver, not a problem maker.</p>
                </div>
            </div>
            <div class="footer-social">
                <ul>
                    <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="#"><i class="fab fa-whatsapp"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="copyright">
        Copyright &copy; 2023 - All rights reserved | This template is made with by MY_Codingan handsome.
    </div>
</div>
