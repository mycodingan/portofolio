<nav id="navbar">
    <div class="Logo">
            <h1><span class="Logo2">my_codingan</span></h1>
    </div>
    <div id="menu-icon" class="menu-icon">
      <i class="ph-fill ph-list"></i>
    </div>
    <ul id="menu-list" class="hidden">
      <li>
        <a href="<?php echo e(route('home')); ?>">Home</a>
      </li>
      <li>
        <a href="<?php echo e(route('about')); ?>">About</a>
      </li>
      <li>
        <a href="<?php echo e(route('project')); ?>">project</a>
      </li>
      <li>
        <a href="<?php echo e(route('serti')); ?>">certificate</a>
      </li>
    </ul>
  </nav>
<?php /**PATH D:\kumpulan project laravel joshua\Portofolio\resources\views/layout/navbar.blade.php ENDPATH**/ ?>